import unittest, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import core
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 40

class T(unittest.TestCase):
    def test_otp_urgent_critical(self):
        r = core.analyze_text("Urgent! share the OTP immediately"); self.assertEqual(r["risk_level"], "Critical"); self.assertIsNone(r["confidence"])
    def test_benign_low_but_hedged(self):
        r = core.analyze_text("Lunch at 1pm tomorrow?"); self.assertEqual(r["risk_level"], "Low"); self.assertIn("does not prove", r["summary"])
    def test_empty_and_long(self):
        for t in ("", "   ", "a" * 10001):
            with self.assertRaises(ValueError): core.analyze_text(t)
    def test_demo_manager_high(self):
        r = core.run_demo("manager"); self.assertTrue(r["demo"]); self.assertIn(r["risk_level"], ("High", "Critical"))
    def test_highlight_escapes_html(self):
        t = "<script>x</script> urgent"; r = core.analyze_text(t)
        self.assertNotIn("<script>", core.highlight(t, [s for i in r["indicators"] for s in i["spans"]]))
    def test_upload_valid_png(self): self.assertEqual(core.validate_upload("image", "a.png", PNG), "png")
    def test_upload_rejects_disguised_exe(self):
        with self.assertRaises(core.UploadError): core.validate_upload("image", "a.png", b"MZ" + b"0" * 50)
    def test_upload_rejects_ext_size_empty(self):
        with self.assertRaises(core.UploadError): core.validate_upload("image", "a.exe", PNG)
        with self.assertRaises(core.UploadError): core.validate_upload("image", "a.png", PNG + b"0" * (11 << 20))
        with self.assertRaises(core.UploadError): core.validate_upload("image", "a.png", b"")
    def test_path_traversal_name(self):
        self.assertEqual(core.validate_upload("image", "../../etc/x.png", PNG), "png"); self.assertNotIn("..", core.safe_temp_name("png"))
    def test_media_unavailable_not_negative(self):
        os.environ.pop("UNPHISHABLE_IMAGE_MODEL", None); r = core.media_analysis("image", "png")
        self.assertFalse(r["analysis_available"]); self.assertEqual(r["model"]["name"], "none"); self.assertIn("NOT a negative", r["summary"])
    def test_rate_limit(self):
        l = core.RateLimiter(2, 60); self.assertTrue(l.allow("a", 1)); self.assertTrue(l.allow("a", 2)); self.assertFalse(l.allow("a", 3)); self.assertTrue(l.allow("a", 100))
    def test_stats_exclude_demo_and_unavailable(self):
        c = core.db(); core.save(c, core.run_demo("otp")); core.save(c, core.media_analysis("image", "png")); core.save(c, core.analyze_text("urgent otp"))
        s = core.stats(c); self.assertEqual(s["total"], 1); self.assertEqual(s["high_risk"], 1)
    def test_raw_message_not_stored(self):
        c = core.db(); core.save(c, core.analyze_text("zzqq-secret-9931 urgent wire")); self.assertNotIn("zzqq-secret-9931", c.execute("SELECT report FROM scans").fetchone()[0])
    def test_identity_never_claims_verified(self): self.assertIn("NOT verified", core.identity_guidance("boss asks urgent payment")["summary"])
    def test_privacy(self): self.assertEqual(core.privacy_assess(["address", "birth", "family"])["risk_level"], "High")
if __name__ == "__main__": unittest.main()
