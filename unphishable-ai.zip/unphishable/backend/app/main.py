"""FastAPI wiring. Run from backend/: uvicorn app.main:app --reload --port 8000"""
import os, logging
from fastapi import FastAPI, UploadFile, File, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
from . import core

log = logging.getLogger("unphishable")
app = FastAPI(title="UnPhishable AI")
app.add_middleware(CORSMiddleware, allow_origins=[os.getenv("FRONTEND_ORIGIN", "http://localhost:8000")], allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
limiter = core.RateLimiter(int(os.getenv("RATE_LIMIT_PER_MIN", "20")))
conn = core.db(os.getenv("DB_PATH", ":memory:"))

@app.middleware("http")
async def guard(request: Request, call_next):
    if request.url.path.startswith("/api/analyze") and not limiter.allow(request.client.host if request.client else "unknown"):
        return JSONResponse({"detail": "Too many requests. Wait a minute and retry."}, 429)
    try: return await call_next(request)
    except Exception:  # no stack traces to users; never log content
        log.exception("unhandled error"); return JSONResponse({"detail": "Internal error."}, 500)

class TextIn(BaseModel):
    text: str = Field(min_length=1, max_length=10000); consent: bool
class PrivacyIn(BaseModel):
    items: list[str] = Field(max_length=20); consent: bool

def _need(c):
    if not c: raise HTTPException(400, "Consent to the privacy notice is required before analysis.")
def _out(r): core.save(conn, r); return r

@app.post("/api/analyze/text")
def text(b: TextIn): _need(b.consent); return _out(core.analyze_text(b.text))
@app.post("/api/analyze/identity")
def identity(b: TextIn): _need(b.consent); return _out(core.identity_guidance(b.text))
@app.post("/api/analyze/privacy")
def privacy(b: PrivacyIn): _need(b.consent); return _out(core.privacy_assess(b.items))

@app.post("/api/analyze/{kind}")
async def media(kind: str, consent: bool = False, file: UploadFile = File(...)):
    _need(consent)
    if kind not in core.EXTS: raise HTTPException(404, "Unknown analyzer.")
    data = await file.read(core.MAX_BYTES[kind] + 1)
    try: fmt = core.validate_upload(kind, file.filename, data)
    except core.UploadError as e: raise HTTPException(422, str(e))
    # Bytes stay in memory. If a detector needs disk, write to a tempfile named core.safe_temp_name(fmt) and delete it in `finally`.
    return _out(core.media_analysis(kind, fmt))

@app.get("/api/demo/{i}")
def demo(i: str):
    try: return core.run_demo(i)
    except ValueError as e: raise HTTPException(404, str(e))
@app.get("/api/stats")
def stats(): return core.stats(conn)
@app.get("/")
def index(): return FileResponse(os.path.join(os.path.dirname(__file__), "../../frontend/index.html"))
