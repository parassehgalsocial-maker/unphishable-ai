"""UnPhishable AI core: stdlib-only analysis + security helpers (framework independent)."""
import re, uuid, sqlite3, time, os, json, html
from datetime import datetime, timezone

LIMITS = ("Rule-based results are heuristics, not proof of fraud or authenticity. "
          "A risk level is NOT the probability that content is fake or real.")

# (id, technique, regex, weight, explanation)
RULES = [
 ("urgency","Urgency / time pressure", r"\b(urgent(ly)?|immediately|right now|asap|within \d+ (minutes?|hours?)|before end of day|don'?t delay|last chance)\b", 2, "Pressure to act before you can think or verify."),
 ("secrecy","Secrecy", r"\b(don'?t tell|keep (this|it) (secret|confidential|between us)|do not (share|discuss)|confidential)\b", 3, "Scammers isolate you so nobody can spot the fraud."),
 ("authority","Authority impersonation", r"\b(ceo|cfo|director|manager|boss|bank (official|manager)|police|tax (office|department)|it (support|helpdesk)|customs)\b", 1, "Claims authority to discourage questioning."),
 ("otp","OTP / code request", r"\b(otp|one[- ]time (password|code)|verification code|security code|6[- ]digit code|pin)\b", 4, "Legitimate organisations never ask you to read out OTPs or PINs."),
 ("payment","Payment request", r"\b(wire|transfer|gift cards?|bitcoin|crypto|upi|bank details|account number|payment|invoice|send money|western union)\b", 2, "Requests money or payment details."),
 ("credentials","Credential theft", r"\b(password|login|log in|sign in|verify your account|account (suspended|locked|will be closed)|reset your)\b", 3, "Tries to capture login credentials."),
 ("threat","Fear / threat", r"\b(arrest|legal action|suspended|penalty|fine|lawsuit|blocked|deactivated|you will lose)\b", 2, "Uses fear of consequences."),
 ("emotion","Emergency / emotional pretext", r"\b(i'?m in (trouble|jail|hospital)|accident|stranded|lost my (phone|wallet)|new number|it'?s me)\b", 3, "Emotional pretext common in relative-impersonation scams."),
 ("link","Link / attachment lure", r"(https?://\S+|\bbit\.ly\b|\bclick (here|the link)\b|\bopen (the )?attachment\b)", 1, "Links can lead to look-alike sites; do not click unverified links."),
]
ACTIONS = [
 "Do not send money, OTPs, passwords or files yet.",
 "Contact the person on a number or channel you already know (not one in the message).",
 "Ask something only the real person could answer, or confirm with a second person.",
 "Report to your IT/security team or bank; in India call 1930 or visit cybercrime.gov.in.",
]

def now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")

def level_from_score(score, flags):
    if "otp" in flags and ({"urgency", "payment"} & flags): return "Critical"
    if score >= 12: return "Critical"
    if score >= 7: return "High"
    if score >= 3: return "Medium"
    return "Low"

def result(input_type, risk, indicators, summary, model="rules-v1", extra=None, confidence=None, available=True):
    r = {"analysis_id": uuid.uuid4().hex, "input_type": input_type, "risk_level": risk,
         "confidence": confidence,  # only ever set by a calibrated model
         "indicators": indicators, "summary": summary,
         "recommended_actions": ACTIONS if risk != "Low" else ["No supported warning signs found, but still verify before sharing sensitive data."],
         "model": {"name": model, "version": "1.0"}, "timestamp": now(),
         "limitations": LIMITS, "analysis_available": available, "demo": False}
    if extra: r.update(extra)
    return r

def analyze_text(text):
    text = (text or "").strip()
    if not text: raise ValueError("Message text is empty.")
    if len(text) > 10000: raise ValueError("Message is too long (max 10,000 characters).")
    inds, flags, score = [], set(), 0
    for rid, tech, rx, w, why in RULES:
        hits = list(re.finditer(rx, text, re.I))
        if hits:
            flags.add(rid); score += w + min(len(hits) - 1, 2)
            inds.append({"id": rid, "technique": tech, "explanation": why, "kind": "observation",
                         "evidence": sorted({m.group(0)[:60] for m in hits})[:5],
                         "spans": [[m.start(), m.end()] for m in hits][:10]})
    risk = level_from_score(score, flags)
    summary = (f"{len(inds)} manipulation technique(s) found; risk {risk} (rule score {score})." if inds
               else "No known manipulation patterns matched. This does not prove the message is safe.")
    return result("text", risk, inds, summary, extra={"rule_score": score})

def highlight(text, spans):
    """Escape first, then mark; safe to render as HTML."""
    out, pos = [], 0
    for s, e in sorted(spans):
        if s < pos: continue
        out += [html.escape(text[pos:s]), "<mark>", html.escape(text[s:e]), "</mark>"]; pos = e
    return "".join(out) + html.escape(text[pos:])

# ---- Uploads: validate by magic bytes, never trust extension/MIME ----
EXTS = {"image": {"jpg","jpeg","png","webp"}, "video": {"mp4","mov"}, "audio": {"wav","mp3","m4a"}}
MAX_BYTES = {"image": 10<<20, "video": 100<<20, "audio": 25<<20}
class UploadError(ValueError): pass

def sniff(kind, h):
    if kind == "image":
        if h.startswith(b"\xff\xd8\xff"): return "jpg"
        if h.startswith(b"\x89PNG\r\n\x1a\n"): return "png"
        if h[:4] == b"RIFF" and h[8:12] == b"WEBP": return "webp"
    if kind == "video" and h[4:8] == b"ftyp":
        return "mov" if h[8:12] == b"qt  " else "mp4"
    if kind == "audio":
        if h[:4] == b"RIFF" and h[8:12] == b"WAVE": return "wav"
        if h.startswith(b"ID3") or h[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"): return "mp3"
        if h[4:8] == b"ftyp": return "m4a"
    return None

def validate_upload(kind, filename, data):
    if kind not in EXTS: raise UploadError("Unknown media type.")
    ext = os.path.splitext(filename or "")[1].lower().lstrip(".")
    if ext not in EXTS[kind]: raise UploadError(f"Unsupported extension. Allowed: {', '.join(sorted(EXTS[kind]))}.")
    if not data: raise UploadError("File is empty.")
    if len(data) > MAX_BYTES[kind]: raise UploadError(f"File too large (max {MAX_BYTES[kind]>>20} MB).")
    fmt = sniff(kind, data[:32])
    if fmt is None: raise UploadError("File content does not match a supported format.")
    return fmt

def safe_temp_name(fmt): return f"{uuid.uuid4().hex}.{fmt}"  # never reuse the client filename

def media_analysis(kind, fmt):
    """A real detector plugs in via UNPHISHABLE_<KIND>_MODEL. Unconfigured => explicit 'unavailable', never a clean result."""
    if not os.getenv(f"UNPHISHABLE_{kind.upper()}_MODEL"):
        return result(kind, "Medium", [], f"File accepted as valid {fmt.upper()}, but no {kind} detection model is configured. "
                      "This is NOT a negative result: the file was not analyzed for manipulation.",
                      model="none", available=False,
                      extra={"unavailable_reason": f"Set UNPHISHABLE_{kind.upper()}_MODEL and implement the detector interface."})
    raise NotImplementedError("Wire your detector here (see README: model interface).")

def identity_guidance(description):
    r = analyze_text(description); r["input_type"] = "identity"
    r["checklist"] = {"Payments": "Call back on a known number; require a second approver.",
                      "Password resets": "Only via the official site you type yourself.",
                      "OTPs": "Never share, with anyone, ever.",
                      "Confidential files": "Confirm via an official channel first.",
                      "Account access": "Do not grant access on a message or call alone."}
    r["summary"] = "Identity NOT verified: this tool cannot verify anyone's real-world identity. " + r["summary"]
    return r

PRIVACY = {"phone": ("Phone number", 2), "address": ("Home address", 3), "birth": ("Date of birth", 3), "employer": ("Employer / job title", 2),
           "family": ("Family names", 3), "email": ("Email address", 1), "travel": ("Travel plans / location tags", 2),
           "voice": ("Public voice/video clips", 3), "photos": ("Face photos", 2)}
def privacy_assess(items):
    inds, score = [], 0
    for k in items:
        if k in PRIVACY:
            n, w = PRIVACY[k]; score += w
            inds.append({"id": k, "technique": n, "kind": "inference", "evidence": [], "explanation": f"{n} can help an impersonator sound credible."})
    risk = "Low" if score < 4 else "Medium" if score < 8 else "High"
    r = result("privacy", risk, inds, f"{len(inds)} exposed item(s) can aid impersonation.", model="privacy-rules-v1")
    r["recommended_actions"] = ["Review public posts and tighten privacy settings.", "Enable multifactor authentication.",
                                "Remove personal details (DOB, address) from public profiles.", "Limit public voice/video clips (used for cloning)."]
    return r

class RateLimiter:
    def __init__(self, n=20, per=60): self.n, self.per, self.h = n, per, {}
    def allow(self, key, t=None):
        t = time.time() if t is None else t; q = [x for x in self.h.get(key, []) if t - x < self.per]
        ok = len(q) < self.n
        if ok: q.append(t)
        self.h[key] = q; return ok

def db(path=":memory:"):
    c = sqlite3.connect(path, check_same_thread=False)
    c.execute("CREATE TABLE IF NOT EXISTS scans(id TEXT PRIMARY KEY,input_type TEXT,risk TEXT,available INT,demo INT,ts TEXT,report TEXT)")
    return c

def save(c, r):  # stores the report (indicators + short evidence snippets) only; never raw message or media
    c.execute("INSERT OR REPLACE INTO scans VALUES(?,?,?,?,?,?,?)", (r["analysis_id"], r["input_type"], r["risk_level"], int(r["analysis_available"]), int(r["demo"]), r["timestamp"], json.dumps(r))); c.commit()

def stats(c):
    real = "demo=0 AND available=1"
    return {"total": c.execute(f"SELECT COUNT(*) FROM scans WHERE {real}").fetchone()[0],
            "high_risk": c.execute(f"SELECT COUNT(*) FROM scans WHERE {real} AND risk IN('High','Critical')").fetchone()[0],
            "by_type": dict(c.execute(f"SELECT input_type,COUNT(*) FROM scans WHERE {real} GROUP BY 1").fetchall()),
            "recent": [json.loads(x[0]) for x in c.execute("SELECT report FROM scans ORDER BY ts DESC LIMIT 10")]}

DEMO = {"manager": "Hi, it's your manager. I'm in a meeting, can't talk. Urgent: wire $4,800 to this new vendor account today and keep this confidential. I'll explain later.",
        "otp": "Your bank account will be suspended within 30 minutes. Share the 6-digit OTP we just sent to verify your account immediately."}
def _canned(kind, risk, s):
    r = result(kind, risk, [{"id": "sample", "technique": "Illustrative indicator", "explanation": s, "kind": "inference", "evidence": []}], s, model="SAMPLE-NOT-A-MODEL")
    r.update(demo=True, demo_label="SAMPLE ONLY: predetermined result, no model ran"); return r
def run_demo(i):
    if i in DEMO:
        r = analyze_text(DEMO[i]); r.update(demo=True, demo_label="DEMO: synthetic message analysed by the rules engine", sample_text=DEMO[i]); return r
    if i == "audio": return _canned("audio", "Medium", "Sample report: synthetic-speech detector flagged unusually regular spectral patterns (illustrative).")
    if i == "image": return _canned("image", "High", "Sample report: blending inconsistency at the face boundary (illustrative).")
    raise ValueError("Unknown demo id.")
