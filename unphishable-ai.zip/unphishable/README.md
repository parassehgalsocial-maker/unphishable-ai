# UnPhishable AI: See Beyond the Face. Verify Before You Trust.

## Run
```
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env && export $(grep -v '^#' .env | xargs)
uvicorn app.main:app --port 8000      # open http://localhost:8000 (API docs: /docs)
python -m unittest tests.test_core -v # core tests (stdlib only)
```
## API (all analysis POSTs need `consent: true`; rate limited per IP)
| Endpoint | Body | Notes |
|---|---|---|
| POST /api/analyze/text, /identity | `{text, consent}` | rule engine |
| POST /api/analyze/privacy | `{items[], consent}` | rule engine |
| POST /api/analyze/{image,video,audio}?consent=true | multipart `file` | magic-byte validation; 422 on bad file |
| GET /api/demo/{manager,otp,audio,image} | | labelled demo/sample output |
| GET /api/stats | | real analyses only |

## Honesty rules
- Text/identity/privacy: documented regex rules (`core.RULES`); levels are rule-weight sums, never "probability fake". `confidence` stays `null` unless a calibrated model sets it.
- Image/video/audio: **no detector is bundled.** Without `UNPHISHABLE_<KIND>_MODEL` the API returns `analysis_available=false` ("NOT a negative result"). Implement the hook in `core.media_analysis` to add a real model; for video, extract frames with `ffmpeg` into a randomly named temp dir and delete in `finally`.
- Audio/image demo items are canned and labelled `SAMPLE-NOT-A-MODEL`.

## Security
Content sniffing, extension allow-list, size caps, random temp names, in-memory handling, rate limiting, CORS pinned to `FRONTEND_ORIGIN`, generic 500s, HTML-escaped rendering (DOM `textContent`), consent gate, no raw content stored or logged. No accounts are implemented, so no auth.

## Demo script (3 min)
1. Home → Try Demo (manager payment request): show highlighted phrases, Critical/High, checklist.
2. Scam analyzer → "OTP under pressure" demo.
3. Upload a PNG: show "analysis unavailable, not a negative result". Upload a renamed .exe: show rejection.
4. Dashboard: demos and unavailable results are excluded from counts.
5. About page: limitations.

## Troubleshooting
`ModuleNotFoundError: multipart` → `pip install python-multipart`. CORS errors → set `FRONTEND_ORIGIN`. 429 → raise `RATE_LIMIT_PER_MIN`.
